import json
from decimal import Decimal
from datetime import date


class CustomEncoder(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, Decimal):
            return float(obj)
        elif isinstance(obj, date):
            return obj.isoformat()
        
        return json.JSONEncoder.default(self, obj)
    
