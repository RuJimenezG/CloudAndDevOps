class Libro():

    def __init__(self, id, titulo=None, autor=None, fecha_inicio=None, fecha_fin=None, genero=None, puntuacion=None) -> None:
        self.id = id
        self.titulo = titulo
        self.autor = autor
        self.fecha_inicio = fecha_inicio
        self.fecha_fin= fecha_fin
        self.genero= genero
        self.puntuacion= puntuacion

    def to_JSON(self):
        return {
            'id': self.id,
            'titulo': self.titulo,
            'autor': self.autor,
            'fecha_inicio': self.fecha_inicio,
            'fecha_fin': self.fecha_fin,
            'genero': self.genero,
            'puntuacion': self.puntuacion
        }