import sys
import os
import logging
import json
import psycopg2
from psycopg2 import DatabaseError
from Libro import Libro
from custom_encoder import CustomEncoder

# El logger para ver los logs en Cloud Watch
logger = logging.getLogger()
logger.setLevel(logging.INFO)

# Definición de los métodos.
getMethod = 'GET'
postMethod = 'POST'

# Definición de las rutas.
librosPath = '/libros'

# Establecer conexión
try:
    print('Conectando a bd')
    connection = psycopg2.connect(
        host=os.environ['host'],          
        user= os.environ['username'], 
        password= os.environ['password'], 
        database= os.environ['database']
        )
except DatabaseError as ex:
    logger.error("ERROR: Error inesperado. No se pudo conectar con la instancia de la base de datos de PostgreSQL.")
    logger.error(ex)
    sys.exit()
logger.info("SUCCESS: Conectado correctamente a la instancia de RDS PostgreSQL.")

# Lógica de la API
def lambda_handler(event, context):
    logger.info(event)
    logger.info("Evento recibido: " + json.dumps(event))
    httpMethod = event['httpMethod']
    path = event['path']
    # Lógica para el uso de una función u otra dependiendo del path y el method.
    if httpMethod == getMethod and path == librosPath:
        response = getLibros()
    elif httpMethod == postMethod and path == librosPath:
        response = postLibros(json.loads(event['body']))
    return response

## Visualizar datos de todos los libros.
def getLibros():
    logger.info("Iniciando consulta")
    libros = []
    #Conexión a la base de datos
    with connection.cursor() as cursor:
                cursor.execute("SELECT id, titulo, autor, fecha_inicio, fecha_fin, genero, puntuacion FROM libros ORDER BY id ASC")
                resultset = cursor.fetchall()
                for row in resultset:
                    
                    libro = Libro(row[0], row[1], row[2], row[3], row[4], row[5], row[6])
                    #Añadir en la lista libros un json con los datos
                    libros.append(libro.to_JSON())
                    body = libros                    
    logger.info(body)
    return buildResponse(200, body)

def postLibros(requestBody):

    new_libro = requestBody
    
    # Realizar la operación INSERT en la base de datos
    with connection.cursor() as cursor:
        query = "INSERT INTO libros (titulo, autor, fecha_inicio, fecha_fin, genero, puntuacion) VALUES (%s, %s, %s, %s, %s, %s)"
        cursor.execute(query, (new_libro['titulo'], new_libro['autor'], new_libro['fecha_inicio'], new_libro['fecha_fin'], new_libro['genero'], new_libro['puntuacion']))
    connection.commit()

    # Ejecutar la consulta SELECT para obtener la lista actualizada de libros
    with connection.cursor() as cursor:
        cursor.execute("SELECT id, titulo, autor, fecha_inicio, fecha_fin, genero, puntuacion FROM libros ORDER BY id ASC")
        resultset = cursor.fetchall()

    # Crear una lista de objetos Libro a partir de los resultados
    libros = []
    for row in resultset:
        libro = Libro(row[0], row[1], row[2], row[3], row[4], row[5], row[6])
        libros.append(libro.to_JSON())

    # Devolver una respuesta HTTP JSON con la lista de libros actualizada
        body = libros                 
    logger.info(body)
    return buildResponse(200, body)

## Definir respuesta.
def buildResponse (statusCode, body=None):
    response = {
        'statusCode': statusCode,
        'headers': {
            'Content-Type': 'application/json',
        }
    }
    if body is not None:
        response['body'] = json.dumps(body, cls=CustomEncoder)
    print(response)
    return response

